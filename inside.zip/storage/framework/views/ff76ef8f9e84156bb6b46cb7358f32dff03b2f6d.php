<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(App\Models\SiteConfig::getAllStiteConfig()->company_title); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset(''.App\Models\SiteConfig::getAllStiteConfig()->favicon)); ?>">

    <!-- CSS
        ============================================ -->
    <!-- CSS
        ============================================ -->

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/vendor/bootstrap.min.css')); ?>"> -->

    <!-- Font Family CSS -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/vendor/cerebrisans.css')); ?>"> -->

    <!-- FontAwesome CSS -->
    

    <!-- Swiper slider CSS -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/plugins/swiper.min.css')); ?>"> -->

    <!-- animate-text CSS -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/plugins/animate-text.css')); ?>"> -->

    <!-- Animate CSS -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/plugins/animate.min.css')); ?>"> -->

    <!-- Light gallery CSS -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/plugins/lightgallery.min.css')); ?>"> -->

    <!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css')}} & plugins.min.css')}} for better website load performance and remove css files from avobe) -->

    <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/vendor/vendor.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/plugins/plugins.min.css')); ?>">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/assets/css/style.css')); ?>">

</head>
<body>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v10.0" nonce="NADFwTZY"></script>
    <div class="preloader-activate preloader-active open_tm_preloader">
        <div class="preloader-area-wrap">
            <div class="spinner d-flex justify-content-center align-items-center h-100">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>
    </div>
    <!--====================  header area ====================-->
    <div class="header-area">
        <div class="header-top-bar-info bg-gray d-none d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="top-bar-wrap">
                            <div class="top-bar-left">
                                <div class="top-bar-text"><?php echo e(strip_tags(App\Models\SiteConfig::getAllStiteConfig()->httext)); ?></div>
                            </div>
                            <div class="top-bar-right">
                                <ul class="top-bar-info">
                                    <li class="info-item">
                                        <a href="tel:<?php echo e(App\Models\SiteConfig::getAllStiteConfig()->phone); ?>" class="info-link">
                                            <i class="info-icon fa fa-phone"></i>
                                            <span class="info-text"><strong><?php echo e(App\Models\SiteConfig::getAllStiteConfig()->phone); ?></strong></span>
                                        </a>
                                    </li>
                                    <li class="info-item">
                                        <i class="info-icon fa fa-map-marker-alt"></i>
                                        <span class="info-text"><?php echo e(Str::of(App\Models\SiteConfig::getAllStiteConfig()->address)->limit(30)); ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header-bottom-wrap header-sticky bg-white">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header position-relative">
                            <!-- brand logo -->
                            <div class="header__logo">
                                <a href="index.html">
                                    <img src="<?php echo e(asset(''.App\Models\SiteConfig::getAllStiteConfig()->logo)); ?>" class="img-fluid" alt="">
                                </a>
                            </div>

                            <div class="header-right">

                                <!-- navigation menu -->
                                <div class="header__navigation menu-style-three d-none d-xl-block">
                                    <nav class="navigation-menu">
                                        <ul>
                                            <li class="has-children has-children--multilevel-submenu">
                                                <a href="#"><span>Home</span></a>
                                                <ul class="submenu">
                                                    <li><a href="index-infotechno.html"><span>Infotechno</span></a></li>
                                                </ul>
                                            </li>
                                            <li class="has-children has-children--multilevel-submenu">
                                                <a href="#"><span>Company</span></a>
                                                <ul class="submenu">
                                                    <li class="has-children">
                                                        <a href="about-us-01.html"><span>About us</span></a>
                                                        <ul class="submenu">
                                                            <li><a href="about-us-01.html"><span>About us 01</span></a></li>
                                                            <li class="has-children">
                                                                <a href="#"><span>Submenu Level Two</span></a>
                                                                <ul class="submenu">
                                                                    <li><a href="#"><span>Submenu Level Three</span></a></li>
                                                                </ul>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li><a href="contact-us.html"><span>Contact us</span></a></li>
                                                </ul>
                                            </li>
                                            <li class="has-children has-children--multilevel-submenu">
                                                <a href="#"><span>IT solutions</span></a>
                                                <ul class="submenu">
                                                    <li><a href="it-services.html"><span>IT Services</span></a></li>
                                                </ul>
                                            </li>
                                            <li class="has-children">
                                                <a href="#"><span>Elements</span></a>
                                                <!-- mega menu -->
                                                <ul class="megamenu megamenu--mega">
                                                    <li>
                                                        <h2 class="page-list-title">ELEMENT GROUP 01</h2>
                                                        <ul>
                                                            <li><a href="element-accordion.html"><span>Accordions & Toggles</span></a></li>
                                                            <li><a href="element-box-icon.html"><span>Box Icon</span></a></li>
                                                        </ul>
                                                    </li>
                                                    <li>
                                                        <h2 class="page-list-title">ELEMENT GROUP 02</h2>
                                                        <ul>
                                                            <li><a href="element-counters.html"><span>Counters</span></a></li>
                                                        </ul>
                                                    </li>
                                                    <li>
                                                        <h2 class="page-list-title">ELEMENT GROUP 03</h2>
                                                        <ul>
                                                            <li><a href="element-popup-video.html"><span>Popup Video</span></a></li>
                                                        </ul>
                                                    </li>
                                                    <li>
                                                        <h2 class="page-list-title">ELEMENT GROUP 04</h2>
                                                        <ul>
                                                            <li><a href="element-testimonials.html"><span>Testimonials</span></a></li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="has-children has-children--multilevel-submenu">
                                                <a href="#"><span>Case Studies</span></a>
                                                <!-- multilevel submenu -->
                                                <ul class="submenu">
                                                    <li><a href="case-studies.html"><span>Case Studies 01</span></a></li>
                                                </ul>
                                            </li>
                                            <li class="has-children has-children--multilevel-submenu">
                                                <a href="blog-list-large-image.html"><span>Blog</span></a>
                                                <!-- multilevel submenu -->
                                                <ul class="submenu">
                                                    <li><a href="blog-list-large-image.html"><span>List Large Image</span></a></li>
                                                    <li class="has-children">
                                                        <a href="blog-post-layout-one.html"><span>Single Layouts</span></a>
                                                        <ul class="submenu">
                                                            <li><a href="blog-post-layout-one.html"><span>Left Sidebar</span></a></li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>

                                <div class="header-search-form-two">
                                    <form action="#" class="search-form-top-active">
                                        <div class="search-icon" id="search-overlay-trigger">
                                            <a href="javascript:void(0)">
                                                <i class="fa fa-search"></i>
                                            </a>
                                        </div>
                                    </form>
                                </div>

                                <!-- mobile menu -->
                                <div class="mobile-navigation-icon d-block d-xl-none" id="mobile-menu-trigger">
                                    <i></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====================  End of header area  ====================-->
    <div id="main-wrapper">
        <div class="site-wrapper-reveal section-space--pt__120">
            <!--============ Service Hero Start ============-->
            <div class="service-hero-wrapper service-hero-space">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php
                             $i=0;
                        ?>
                        <?php $__currentLoopData = App\Models\Hero::getAllHero(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $i++;
                            ?>
                            <?php if($i==1): ?>
                                <div class="carousel-item active">
                                    <img src="<?php echo e(asset(''.$hero->img)); ?>" alt="<?php echo e($hero->alt); ?>" class="w-100">
                                    <div class="carousel-caption d-none d-md-block">
                                        <h3 class="text-white"><?php echo e($hero->title); ?></h3>
                                        <h5 class="text-white"><?php echo e($hero->caption); ?></h5>
                                    </div>
                                </div><!-- .carousel-item end -->
                            <?php else: ?>
                                <div class="carousel-item">
                                    <img src="<?php echo e(asset(''.$hero->img)); ?>" alt="<?php echo e($hero->alt); ?>" class="w-100">
                                    <div class="carousel-caption d-none d-md-block">
                                        <h3 class="text-white"><?php echo e($hero->title); ?></h3>
                                        <h5 class="text-white"><?php echo e($hero->caption); ?></h5>
                                    </div>
                                </div><!-- .carousel-item end -->
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
            <!--============ Service Hero End ============-->
            <!--===========  feature-images-wrapper  Start =============-->
            <div class="feature-images-wrapper position-relative">
                <div class="swiper-container service-slider__container">
                    <div class="swiper-wrapper service-slider__wrapper feature-images__three">
                        <?php $__currentLoopData = App\Models\Product::getAllProduct(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <!-- ht-box-icon Start -->
                            <a href="<?php echo e(route('product.show', $product->id)); ?>" class="ht-box-images style-03 wow move-up">
                                <div class="image-box-wrap">
                                    <div class="box-image">
                                        <img class="img-fluid" src="<?php echo e(asset(''.$product->image)); ?>" alt="<?php echo e($product->alt); ?>">
                                    </div>
                                    <div class="content">
                                        <h6 class="heading"><?php echo e($product->name); ?></h6>
                                        <div class="text"><?php echo e(Str::of(strip_tags($product->description))->limit(80)); ?></div>
                                    </div>
                                </div>
                            </a>
                            <!-- ht-box-icon End -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="swiper-pagination swiper-pagination-service section-space--mt_30"></div>
                </div>
            </div>
            <!--===========  feature-images-wrapper  End =============-->




            <!--===========  Our Company History Start =============-->

            <div class="our-company-history pt-5">
                <div class="container-fluid">

                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="faq-custom-col">
                                <div class="section-title-wrap">
                                    <h6 class="section-sub-title mb-20">Our company</h6>
                                    <h3 class="heading"><?php echo e(App\Models\AboutUs::getAboutUs()->title); ?></h3>

                                    <p class="text mt-30"><?php echo e(Str::of(strip_tags(App\Models\AboutUs::getAboutUs()->description))->limit(300)); ?></p>

                                    <div class="inner-button-box section-space--mt_60">
                                        <a href="" class="ht-btn ht-btn-md">Find out more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="rv-video-section">

                                

                                <div class="main-video-box video-popup">
                                    <a href="<?php echo e(App\Models\AboutUs::getAboutUs()->video_link); ?>" class="video-link  mt-30">
                                        <div class="single-popup-wrap">
                                            <img class="img-fluid border-radus-5" src="<?php echo e(asset(''.App\Models\AboutUs::getAboutUs()->video_thumbnail)); ?>" alt="">
                                            <div class="ht-popup-video video-button">
                                                <div class="video-mark">
                                                    <div class="wave-pulse wave-pulse-1"></div>
                                                    <div class="wave-pulse wave-pulse-2"></div>
                                                </div>
                                                <div class="video-button__two">
                                                    <div class="video-play">
                                                        <span class="video-play-icon"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--===========  Our Company History Start  End =============-->

            <!--===========  feature-icon-wrapper  Start =============-->
            <div class="feature-icon-wrapper bg-gray section-space--ptb_100">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title-wrap text-center section-space--mb_40">
                                <h6 class="section-sub-title mb-20">Industries we Serve</h6>
                                <h3 class="heading">Services We Deliver<br> we provide <span class="text-color-primary"> truly prominent IT solutions.</span></h3>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="feature-list__two">
                                <div class="row">
                                    <?php $__currentLoopData = App\Models\Service::getAllService(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-4 col-md-6 wow move-up" style="padding-left:0px; padding-right:0px;">
                                            <div class="ht-box-icon style-02 single-svg-icon-box">
                                                <div class="icon-box-wrap">



                                                    <div class="card">
                                                        <img class="card-img-top" src="<?php echo e(asset(''.$service->image)); ?>" alt="Card image cap">
                                                        <div class="svg-icon d-none" id="svg-3" data-svg-icon="<?php echo e(asset('/frontend/assets/images/svg/linea-basic-alarm.svg')); ?>"></div>
                                                        <div class="card-body">
                                                            <h6 class="heading mb-2"><?php echo e($service->name); ?></h6>
                                                            <p class="card-text"><?php echo e(Str::of(strip_tags($service->description))->limit(120)); ?></p>
                                                            <a href="" class="btn btn-xs btn-primary">Know More</a>
                                                        </div>
                                                      </div>


                                                    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="feature-list-button-box mt-30 text-center">
                                <a href="#" class="ht-btn ht-btn-md">Talk to a consultant</a>
                                <a href="" class="ht-btn ht-btn-md ht-btn--outline">Contact us now </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--===========  feature-icon-wrapper  End =============-->



            <!--====================  gradation process area ====================-->
            <div class="gradation-process-area section-space--ptb_100">
                <div class="container">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="gradation-title-wrapper section-space--mb_60">
                                <div class="gradation-title-wrap ">
                                    <h6 class="section-sub-title text-black mb-20">How we works</h6>
                                    <h4 class="heading">How it helps <span class="text-color-primary">your <br> business succeed</span></h4>
                                </div>


                                <div class="gradation-sub-heading">
                                    <h3 class="heading"><mark>04</mark> Steps</h3>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ht-gradation style-01">
                                <!-- Single item gradation Start -->
                                <div class="item item-1 animate  wow fadeInRight" data-wow-delay="0.1s">
                                    <div class="line"></div>
                                    <div class="circle-wrap">
                                        <div class="mask">
                                            <div class="wave-pulse wave-pulse-1"></div>
                                            <div class="wave-pulse wave-pulse-2"></div>
                                            <div class="wave-pulse wave-pulse-3"></div>
                                        </div>

                                        <h6 class="circle">1</h6>
                                    </div>

                                    <div class="content-wrap">

                                        <h6 class="heading">01. Discussion</h6>

                                        <div class="text">We meet customers in set place to discuss the details about needs and demands before proposing a plan.</div>

                                        <a class="gradation-btn" href="#">
                                            <span class="button-text" data-text="Look more">
                                        Look more </span>
                                            <span class="button-icon far fa-long-arrow-right"></span>
                                        </a>
                                    </div>
                                </div>
                                <!-- Single item gradation End -->

                                <!-- Single item gradation Start -->
                                <div class="item item-1 animate  wow fadeInRight" data-wow-delay="0.15s">
                                    <div class="line"></div>
                                    <div class="circle-wrap">
                                        <div class="mask">
                                            <div class="wave-pulse wave-pulse-1"></div>
                                            <div class="wave-pulse wave-pulse-2"></div>
                                            <div class="wave-pulse wave-pulse-3"></div>
                                        </div>

                                        <h6 class="circle">2</h6>
                                    </div>

                                    <div class="content-wrap">

                                        <h6 class="heading">02. Concepts &amp; Initatives</h6>

                                        <div class="text">Our experts come up with all kinds of ideas and initiatives for delivering the best solutions for IT services chosen.</div>

                                        <a class="gradation-btn" href="#">
                                            <span class="button-text" data-text="Look more">
                                        Look more </span>
                                            <span class="button-icon far fa-long-arrow-right"></span>
                                        </a>
                                    </div>
                                </div>
                                <!-- Single item gradation End -->

                                <!-- Single item gradation Start -->
                                <div class="item item-1 animate  wow fadeInRight" data-wow-delay="0.20s">
                                    <div class="line"></div>
                                    <div class="circle-wrap">
                                        <div class="mask">
                                            <div class="wave-pulse wave-pulse-1"></div>
                                            <div class="wave-pulse wave-pulse-2"></div>
                                            <div class="wave-pulse wave-pulse-3"></div>
                                        </div>

                                        <h6 class="circle">3</h6>
                                    </div>

                                    <div class="content-wrap">

                                        <h6 class="heading">03. Testing &amp; Trying</h6>

                                        <div class="text">After agreeing on the ideas and plans, we will conduct as scheduled and give comments on the results &amp; adaptations.</div>

                                        <a class="gradation-btn" href="#">
                                            <span class="button-text" data-text="Look more">
                                        Look more </span>
                                            <span class="button-icon far fa-long-arrow-right"></span>
                                        </a>
                                    </div>
                                </div>
                                <!-- Single item gradation End -->

                                <!-- Single item gradation Start -->
                                <div class="item item-1 animate wow fadeInRight" data-wow-delay="0.25s">
                                    <div class="line"></div>
                                    <div class="circle-wrap">
                                        <div class="mask">
                                            <div class="wave-pulse wave-pulse-1"></div>
                                            <div class="wave-pulse wave-pulse-2"></div>
                                            <div class="wave-pulse wave-pulse-3"></div>
                                        </div>

                                        <h6 class="circle">4</h6>
                                    </div>

                                    <div class="content-wrap">

                                        <h6 class="heading">04. Execute &amp; install</h6>

                                        <div class="text">Once the final plan is approved, everything will be conducted according to the agreed contract.</div>

                                        <a class="gradation-btn" href="#">
                                            <span class="button-text" data-text="Look more">
                                        Look more </span>
                                            <span class="button-icon far fa-long-arrow-right"></span>
                                        </a>
                                    </div>
                                </div>
                                <!-- Single item gradation End -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====================  End of gradation process area  ====================-->

            <!--========== Call to Action Area Start ============-->
            <div class="cta-image-area_one section-space--ptb_80 cta-bg-image_one">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-8 col-lg-7">
                            <div class="cta-content md-text-center">
                                <h3 class="heading text-white">We run all kinds of IT services that vow your <span class="text-color-secondary"> success</span></h3>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5">
                            <div class="cta-button-group--one text-center">
                                <a href="#" class="btn btn--white btn-one"><span class="btn-icon mr-2"><i class="far fa-comment-alt-dots"></i></span> Let's talk</a>
                                <a href="#" class="btn btn--secondary  btn-two"><span class="btn-icon mr-2"><i class="far fa-info-circle"></i></span> Get info</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--========== Call to Action Area End ============-->

            <!--=========== Service Projects Wrapper Start =============-->
            
            <!--=========== Service Projects Wrapper End =============-->

            <!--========= Pricing Table Area Start ==========-->
            
            <!--========= Pricing Table Area End ==========-->
            <!--=========== Service Projects Wrapper Start =============-->
            
            <!--=========== Service Projects Wrapper End =============-->

            <!--============ Contact Us Area Start =================-->
            <div class="contact-us-area service-contact-bg section-space--ptb_100">
                <div class="container">
                    <div class="row align-items-center">

                        <div class="col-lg-4">
                            <div class="contact-info sytle-one service-contact text-left">

                                <div class="contact-info-title-wrap text-center">
                                    <h3 class="heading text-white mb-10">4.9/5.0</h3>
                                    <div class="ht-star-rating lg-style">
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    </div>
                                    <p class="sub-text">by 700+ customers for 3200+ clients</p>
                                </div>

                                <div class="contact-list-item">
                                    <a href="tel:190068668" class="single-contact-list">
                                        <div class="content-wrap">
                                            <div class="content">
                                                <div class="icon">
                                                    <span class="fal fa-phone"></span>
                                                </div>
                                                <div class="main-content">
                                                    <h6 class="heading">Call for advice now!</h6>
                                                    <div class="text"><?php echo e(App\Models\SiteConfig::getAllStiteConfig()->phone); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <a href="mailto:hello@mitech.com" class="single-contact-list">
                                        <div class="content-wrap">
                                            <div class="content">
                                                <div class="icon">
                                                    <span class="fal fa-envelope"></span>
                                                </div>
                                                <div class="main-content">
                                                    <h6 class="heading">Say hello</h6>
                                                    <div class="text"><?php echo e(App\Models\SiteConfig::getAllStiteConfig()->email); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>

                            </div>
                        </div>

                        <div class="col-lg-7 ml-auto">
                            <div class="contact-form-service-wrap">
                                <div class="contact-title text-center section-space--mb_40">
                                    <h3 class="mb-10">Need a hand?</h3>
                                    <p class="text">Reach out to the world’s most reliable IT services.</p>
                                </div>

                                <form action="<?php echo e(route('message.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="contact-form__two">
                                        <div class="contact-input">
                                            <div class="contact-inner">
                                                <input name="name" type="text" placeholder="Name *">
                                            </div>
                                            <div class="contact-inner">
                                                <input name="email" type="email" placeholder="Email *">
                                            </div>
                                        </div>
                                        <div class="contact-select">
                                            <div class="form-item contact-inner">
                                                <span class="inquiry">
                                                    <input type="text" placeholder="Subject" name="subject">
                                                </span>
                                            </div>
                                        </div>
                                        <div class="contact-inner contact-message">
                                            <textarea name="message" placeholder="Please describe what you need."></textarea>
                                        </div>
                                        <div class="comment-submit-btn">
                                            <button class="ht-btn ht-btn-md" type="submit">Send message</button>
                                            <p class="form-messege-2"></p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!--============ Contact Us Area End =================-->
            <!--====================  brand logo slider area ====================-->
            <div class="brand-logo-slider-area section-space--ptb_60">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- brand logo slider -->
                            <div class="brand-logo-slider__container-area">
                                <div class="swiper-container brand-logo-slider__container">
                                    <div class="swiper-wrapper brand-logo-slider__one">
                                        <?php $__currentLoopData = App\Models\Client::getAllClient(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="<?php echo e($client->link); ?>">
                                                <div class="brand-logo__image">
                                                    <img src="<?php echo e(asset(''.$client->image)); ?>" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="<?php echo e(asset(''.$client->image)); ?>" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====================  End of brand logo slider area  ====================-->
        </div>




        <!--====================  footer area ====================-->
        <div class="footer-area-wrapper reveal-footer bg-gray">
            <div class="footer-area section-space--ptb_100">
                <div class="container">
                    <div class="row footer-widget-wrapper">
                        <div class="col-lg-4 col-md-6 col-sm-6 footer-widget">
                            <div class="footer-widget__logo mb-30">
                                <img src="<?php echo e(asset(''.App\Models\SiteConfig::getAllStiteConfig()->logo)); ?>" class="img-fluid" alt="">
                            </div>
                            <ul class="footer-widget__list">
                                <li><i class="info-icon fa fa-map-marker-alt"> </i> <?php echo e(App\Models\SiteConfig::getAllStiteConfig()->address); ?></li>
                                <li><i class="fal fa-envelope"> </i> <a href="mailto:<?php echo e(App\Models\SiteConfig::getAllStiteConfig()->email); ?>" class="hover-style-link"><?php echo e(App\Models\SiteConfig::getAllStiteConfig()->email); ?></a></li>
                                <li><i class="info-icon fa fa-phone"> </i> <a href="tel:<?php echo e(App\Models\SiteConfig::getAllStiteConfig()->phone); ?>" class="hover-style-link text-black font-weight--bold"><?php echo e(App\Models\SiteConfig::getAllStiteConfig()->phone); ?></a></li>
                                <li><a href="https://pro-alam.com/" class="hover-style-link text-color-primary">www.pro-alam.com</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 footer-widget">
                            <h6 class="footer-widget__title mb-20">IT Services</h6>
                            <ul class="footer-widget__list">
                                <?php $__currentLoopData = App\Models\Service::getSixService(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('service.show', $service->id)); ?>" class="hover-style-link"><?php echo e($service->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-lg-4 col-md-8 col-sm-12 footer-widget">
                            <h6 class="footer-widget__title mb-20 text-center">Facebook Page</h6>
                            <div class="fb-page" data-href="<?php echo e(App\Models\Social::getSocial()->facebook_page); ?>" data-tabs="timeline" data-width="" data-height="280px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="<?php echo e(App\Models\Social::getSocial()->facebook_page); ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo e(App\Models\Social::getSocial()->facebook_page); ?>">Facebook</a></blockquote></div>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 footer-widget">
                            <div class="footer-widget__title section-space--mb_50"></div>
                            <ul class="footer-widget__list">
                                <li><a href="#" class="image_btn"><img class="img-fluid" src="<?php echo e(asset('/frontend/assets/images/icons/aeroland-button-google-play.jpg')); ?>" alt=""></a></li>
                                <li><a href="#" class="image_btn"><img class="img-fluid" src="<?php echo e(asset('/frontend/assets/images/icons/aeroland-button-app-store.jpg')); ?>" alt=""></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-copyright-area section-space--pb_30">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-left">
                            <span class="copyright-text">&copy; 2019 <?php echo e(App\Models\SiteConfig::getAllStiteConfig()->company_name); ?>. <a href="#">All Rights Reserved.</a></span>
                        </div>
                        <div class="col-md-6 text-center text-md-right">
                            <ul class="list ht-social-networks solid-rounded-icon">

                                <li class="item">
                                    <a href="<?php echo e(App\Models\Social::getSocial()->twitter); ?>" target="_blank" aria-label="Twitter" class="social-link hint--bounce hint--top hint--primary">
                                        <i class="fab fa-twitter link-icon"></i>
                                    </a>
                                </li>
                                <li class="item">
                                    <a href="<?php echo e(App\Models\Social::getSocial()->facebook); ?>" target="_blank" aria-label="Facebook" class="social-link hint--bounce hint--top hint--primary">
                                        <i class="fab fa-facebook-f link-icon"></i>
                                    </a>
                                </li>
                                <li class="item">
                                    <a href="<?php echo e(App\Models\Social::getSocial()->instagram); ?>" target="_blank" aria-label="Instagram" class="social-link hint--bounce hint--top hint--primary">
                                        <i class="fab fa-instagram link-icon"></i>
                                    </a>
                                </li>
                                <li class="item">
                                    <a href="<?php echo e(App\Models\Social::getSocial()->linkedin); ?>" target="_blank" aria-label="Linkedin" class="social-link hint--bounce hint--top hint--primary">
                                        <i class="fab fa-linkedin link-icon"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--====================  End of footer area  ====================-->
    </div>
    <!--====================  search overlay ====================-->
    <div class="search-overlay" id="search-overlay">

        <div class="search-overlay__header">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-6 ml-auto col-4">
                        <!-- search content -->
                        <div class="search-content text-right">
                            <span class="mobile-navigation-close-icon" id="search-close-trigger"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="search-overlay__inner">
            <div class="search-overlay__body">
                <div class="search-overlay__form">
                    <form action="#">
                        <input type="text" placeholder="Search">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--====================  End of search overlay  ====================-->

    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="<?php echo e(asset('/frontend/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

    <!-- jQuery JS -->
    <script src="<?php echo e(asset('/frontend/assets/js/vendor/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/frontend/assets/js/vendor/jquery-migrate-3.3.0.min.js')); ?>"></script>

    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('/frontend/assets/js/vendor/bootstrap.min.js')); ?>"></script>

    <!-- wow JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/wow.min.js')); ?>"></script> -->

    <!-- Swiper Slider JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/swiper.min.js')); ?>"></script> -->

    <!-- Light gallery JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/lightgallery.min.js')); ?>"></script> -->

    <!-- Waypoints JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/waypoints.min.js')); ?>"></script> -->

    <!-- Counter down JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/countdown.min.js')); ?>"></script> -->

    <!-- Isotope JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/isotope.min.js')); ?>"></script> -->

    <!-- Masonry JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/masonry.min.js')); ?>"></script> -->

    <!-- ImagesLoaded JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/images-loaded.min.js')); ?>"></script> -->

    <!-- Wavify JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/wavify.js')); ?>"></script> -->

    <!-- jQuery Wavify JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/jquery.wavify.js')); ?>"></script> -->

    <!-- circle progress JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/circle-progress.min.js')); ?>"></script> -->

    <!-- counterup JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/counterup.min.js')); ?>"></script> -->


    <!-- animation text JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/animation-text.min.js')); ?>"></script> -->

    <!-- Vivus JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/vivus.min.js')); ?>"></script> -->

    <!-- Some plugins JS -->
    <!-- <script src="<?php echo e(asset('/frontend/assets/js/plugins/some-plugins.js')); ?>"></script> -->


    <!-- Plugins JS (Please remove the comment from below plugins.min.js')}} for better website load performance and remove plugin js files from avobe) -->


    <script src="<?php echo e(asset('/frontend/assets/js/plugins/plugins.min.js')); ?>"></script>


    <!-- Main JS -->
    <script src="<?php echo e(asset('/frontend/assets/js/main.js')); ?>"></script>


</body>

</html><?php /**PATH C:\xampp\htdocs\inside\resources\views/frontend/index.blade.php ENDPATH**/ ?>