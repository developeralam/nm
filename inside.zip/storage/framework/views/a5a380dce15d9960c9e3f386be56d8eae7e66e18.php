
<?php $__env->startSection('title', 'Add Service'); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <h4 class="page-title pull-left">Service</h4>
    <ul class="breadcrumbs pull-left">
        <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
        <li><span>Add Service</span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="about-us">  
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Add Service</h3>
            </div>
            <div class="card-body">
                <div class="site-config-form">
                    <form action="<?php echo e(route('service.store')); ?>" method="post" class="w-75 m-auto" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name" class="col-form-lebel">Service Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Enter Service Name" autocomplete="name" autofocus value="<?php echo e(old('name')); ?>" required>
                            <div class="text-danger">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="image" class="col-form-lebel">Service Image</label>
                            <input type="file" name="image" id="image" class="form-control">
                            <div class="text-danger">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="alt" class="col-form-lebel">Service Image Alt</label>
                            <input type="text" class="form-control" name="alt" id="alt" placeholder="Enter Service Image Alt" autocomplete="alt" autofocus value="<?php echo e(old('alt')); ?>" required>
                            <div class="text-danger">
                                <?php $__errorArgs = ['alt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="description" class="col-form-lebel">Description</label>
                            <textarea name="description" id="editor" cols="30" rows="10"><?php echo e(old('description', $about->description??null)); ?></textarea>
                            <div class="text-danger">
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button class="btn btn-success" type="submit">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-script'); ?>
<?php $__env->startSection('custom-script'); ?>
<script>
    ClassicEditor.create( document.querySelector( '#editor' ), {
        // toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
    } )
    .then( editor => {
        window.editor = editor;
    } )
    .catch( err => {
        console.error( err.stack );
    } );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inside\resources\views/backend/service/create.blade.php ENDPATH**/ ?>