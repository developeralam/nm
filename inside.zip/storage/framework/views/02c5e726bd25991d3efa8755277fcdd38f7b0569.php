
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <h4 class="page-title pull-left">Dashboard</h4>
    <ul class="breadcrumbs pull-left">
        <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
        <li><span>Dashboard</span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="message">
    <div class="card">
        <div class="card-header">
            <h3 class="text-center">Unread Message List</h3>
        </div>
        <div class="card-body">
            <div class="data-tables">
                <table id="dataTable" class="text-center table-striped">
                    <thead class="bg-light text-capitalize">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col" width="15%">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Message</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = App\Models\Message::getAllUnreadMessage(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index+1); ?></th>
                                <td><?php echo e($message->name); ?></td>
                                <td><?php echo e($message->email); ?></td>
                                <td><?php echo e(Str::of($message->message)->limit(30)); ?></td>
                                <td>
                                    <ul class="d-flex justify-content-center">
                                            <li>
                                                <form action="<?php echo e(route('messages.update', $message->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <button class="btn btn-success btn-sm border-0 mr-2" type="submit">Archive</button>
                                                </form>
                                            </li>
                                            <li>
                                                <form action="<?php echo e(route('messages.destroy', $message->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-sm btn-danger border-0" type="submit">Delete</button>
                                                </form>
                                            </li>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inside\resources\views/backend/index.blade.php ENDPATH**/ ?>