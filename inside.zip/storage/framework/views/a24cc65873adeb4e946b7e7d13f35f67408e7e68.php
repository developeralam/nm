
<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <h4 class="page-title pull-left">About Us</h4>
    <ul class="breadcrumbs pull-left">
        <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
        <li><span>About Us</span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="about-us">  
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">About Us</h3>
            </div>
            <div class="card-body">
                <div class="site-config-form">
                    <form action="<?php echo e($about ? route('aboutus.update', $about->id): route('aboutus.store')); ?>" method="post" class="w-75 m-auto" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(!empty($about)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="title" class="col-form-lebel">Title</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" id="title" placeholder="Enter Your Title" autocomplete="title" autofocus value="<?php echo e(old('title', $about->title??null)); ?>">
                            <div class="text-danger">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="description" class="col-form-lebel">Description</label>
                            <textarea name="description" id="editor" cols="30" rows="10"><?php echo e(old('description', $about->description??null)); ?></textarea>
                            <div class="text-danger">
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="video-link" class="col-form-lebel">Video LInk</label>
                            <textarea name="video_link" id="video_link" class="form-control" cols="30" rows="10"><?php echo e(old('video_link', $about->video_link??null)); ?></textarea>
                            <div class="text-danger">
                                <?php $__errorArgs = ['video-link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="video_thumbnail" class="col-form-lebel">Video Thumbnail</label>
                            <input type="file" name="video_thumbnail" id="video_thumbnail" class="form-control">
                            <div class="text-danger">
                                <?php $__errorArgs = ['video_thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="banner1" class="col-form-lebel">Banner 1</label>
                            <input type="file" name="banner1" id="banner1" class="form-control">
                            <div class="text-danger">
                                <?php $__errorArgs = ['banner1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="banner2" class="col-form-lebel">Banner 2</label>
                            <input type="file" name="banner2" id="banner2" class="form-control">
                            <div class="text-danger">
                                <?php $__errorArgs = ['banner2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="banner3" class="col-form-lebel">Banner 3</label>
                            <input type="file" name="banner3" id="banner3" class="form-control">
                            <div class="text-danger">
                                <?php $__errorArgs = ['banner3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="banner4" class="col-form-lebel">Banner 4</label>
                            <input type="file" name="banner4" id="banner4" class="form-control">
                            <div class="text-danger">
                                <?php $__errorArgs = ['banner4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span>
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button class="btn btn-success" type="submit">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-script'); ?>
<?php $__env->startSection('custom-script'); ?>
<script>
    ClassicEditor.create( document.querySelector( '#editor' ), {
        // toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
    } )
    .then( editor => {
        window.editor = editor;
    } )
    .catch( err => {
        console.error( err.stack );
    } );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inside\resources\views/backend/aboutus/index.blade.php ENDPATH**/ ?>