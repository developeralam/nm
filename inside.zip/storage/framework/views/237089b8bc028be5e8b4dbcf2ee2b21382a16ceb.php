
<?php $__env->startSection('title', 'Add Client'); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <h4 class="page-title pull-left">Add Client</h4>
    <ul class="breadcrumbs pull-left">
        <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
        <li><span>Add Client</span></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="site-config">
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Add Client</h3>
            </div>
            <div class="card-body">
                <div class="hero-form">
                    <form action="<?php echo e(route('client.store')); ?>" method="post" class="w-75 m-auto" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class="form-group">
                                <label for="image" class="col-form-lebel">Client Image</label>
                                <input type="file" class="form-control" name="image" id="image" autocomplete="image" autofocus>
                                <div class="text-danger">
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span>
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="link" class="col-form-lebel">Client Url</label>
                                <input type="text" class="form-control" name="link" id="link" autocomplete="link" autofocus value="<?php echo e(old('link')); ?>">
                                <div class="text-danger">
                                    <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span>
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <button class="btn btn-success" type="submit">Add Client</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inside\resources\views/backend/client/create.blade.php ENDPATH**/ ?>